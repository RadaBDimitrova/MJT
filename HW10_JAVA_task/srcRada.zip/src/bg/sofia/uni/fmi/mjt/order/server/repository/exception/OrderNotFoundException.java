package bg.sofia.uni.fmi.mjt.order.server.repository.exception;

public class OrderNotFoundException {
}
