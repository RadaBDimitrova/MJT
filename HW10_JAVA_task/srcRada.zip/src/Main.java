
import bg.sofia.uni.fmi.mjt.order.client.ClientOrder;
import bg.sofia.uni.fmi.mjt.order.server.OrderServer;

public class Main {

    public static void main(String[] args) {
        // Start the server in a separate thread
        Thread serverThread = new Thread(() -> OrderServer.main(null));
        serverThread.start();

        Thread clientThread = new Thread(() -> {
            try {
                Thread.sleep(1000); // Wait for the server to start
                ClientOrder.main(null);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        clientThread.start();

        // Wait for both threads to finish
        try {
            serverThread.join();
            clientThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
