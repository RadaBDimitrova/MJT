package bg.sofia.uni.fmi.mjt.edamam;

import bg.sofia.uni.fmi.mjt.recipe.Recipe;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

class EdamamResponseParserTest {

    @Test
    void testParseRecipes() {
        String responseBody = """
                {
                  "hits": [
                    {
                      "recipe": {
                        "label": "Recipe 1"
                      }
                    },
                    {
                      "recipe": {
                        "label": "Recipe 2"
                      }
                    }
                  ]
                }
                """;

        EdamamResponseParser responseParser = new EdamamResponseParser();
        List<Recipe> recipes = responseParser.parseRecipes(responseBody);

        assertEquals(2, recipes.size());
        assertEquals("Recipe 1", recipes.get(0).label());
        assertEquals("Recipe 2", recipes.get(1).label());
    }

    @Test
    void testCalculatePagesCount() {
        EdamamResponseParser responseParser = new EdamamResponseParser();

        String responseBody = """
                {
                  "count": 27
                }
                """;

        int resultsPerPage = 20;
        int pagesToLoad = 3;
        int pagesCount = responseParser.calculatePagesCount(responseBody, resultsPerPage, pagesToLoad);

        assertEquals(2, pagesCount);
    }

    @Test
    void testGetTotalRecipes() {
        EdamamResponseParser responseParser = new EdamamResponseParser();

        String responseBody = """
                {
                  "count": 22
                }
                """;

        int totalCount = responseParser.getTotalRecipes(responseBody);
        assertEquals(22, totalCount);
    }

    @Test
    void testParseNextLink() {
        EdamamResponseParser responseParser = new EdamamResponseParser();

        String responseBody = """
                {
                  "_links": {
                    "next": {
                      "href": "https://api.example.com/next"
                    }
                  }
                }
                """;

        String nextLink = responseParser.parseNextLink(responseBody);
        assertEquals("https://api.example.com/next", nextLink);
    }
}

