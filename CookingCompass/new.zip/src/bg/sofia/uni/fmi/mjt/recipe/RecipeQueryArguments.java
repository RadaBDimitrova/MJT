package bg.sofia.uni.fmi.mjt.recipe;

import java.util.List;

public record RecipeQueryArguments(String keywords, List<String> mealTypes, List<String> healthLabels) {

}


