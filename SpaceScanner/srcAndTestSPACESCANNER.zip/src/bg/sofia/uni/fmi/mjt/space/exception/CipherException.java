package bg.sofia.uni.fmi.mjt.space.exception;

public class CipherException extends Exception {

    public CipherException(String message, Exception e) {
        super(message, e);
    }

}
